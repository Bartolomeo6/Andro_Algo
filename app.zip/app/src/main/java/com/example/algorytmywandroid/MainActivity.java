package com.example.algorytmywandroid;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Random;

public class MainActivity extends AppCompatActivity {

    ArrayList<Integer> arrayListLiczby = new ArrayList<>();
    ListView listaWyswietlanych;
    Button sprawdzPrzycisk;
    EditText podanaLiczba;
    TextView wynikDzialania;
    ArrayAdapter<Integer> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        listaWyswietlanych = findViewById(R.id.listaLiczb);
        sprawdzPrzycisk = findViewById(R.id.buttonSprawdz);
        podanaLiczba = findViewById(R.id.editTextLiczba);
        wynikDzialania = findViewById(R.id.textViewWynik);

        adapter = new ArrayAdapter<Integer>(this, android.R.layout.simple_list_item_1, arrayListLiczby);
        listaWyswietlanych.setAdapter(adapter);


        sprawdzPrzycisk.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        arrayListLiczby.addAll(losowanie(Integer.parseInt(podanaLiczba.getText().toString())));
                        sortowanieWybor(arrayListLiczby);
                        adapter.notifyDataSetChanged();
                    }
                }
        );
    }

    private ArrayList<Integer> losowanie(int n){
        ArrayList<Integer> liczby = new ArrayList<>();
        Random random = new Random();
        for(int i = 0; i<n; i++){
            liczby.add(random.nextInt(50)+5);
        }
        return liczby;
    }

    private ArrayList<Integer> sortowanieWybor(ArrayList<Integer> liczby){
        int najmIndeks = 0;
        for(int i = 0; i<liczby.size()-1; i++){
            najmIndeks = i;
            for(int j = i+1; j<liczby.size(); j++){
                if(liczby.get(j) < liczby.get(najmIndeks)){
                    najmIndeks = j;
                }
            }
            if(najmIndeks != i){
                int temp = liczby.get(najmIndeks);
                liczby.set(najmIndeks, i);
                liczby.set(i, temp);
            }
        }
        return liczby;
    }
}